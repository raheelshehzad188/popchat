import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pchat',
  templateUrl: './pchat.component.html',
  styleUrls: ['./pchat.component.scss'],
})
export class PchatComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
